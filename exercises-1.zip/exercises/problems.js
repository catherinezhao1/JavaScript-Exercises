window.answers = () => {
    // Each of the following sections is a separate problem. Read the comments and do what they say.
    // Don't delete or change the instructional comments
    
    // #1 Add the fewest number of brackets so that result is equal to 65.
    // (don't add, remove or change the numbers)
    let result = 1 + 2 ** 2 * 3


    // #2 The variable 'fruity' should equal "a banana".
    // Uncomment (remove the //) the one line of code that does this correctly.
    const w = " "
    const x = "a"
    const y = " ba"
    const z = "na"
    // const fruity = x yzz
    // const fruity = xyzz
    // const fruity = x + y + z + z
    // const fruity = x + w + y + z + z


    // #3 A variable, named 'fruity2', should equal "a ba ba banana na".
    // Write an expression, using w, x, y, z as above, to make this happen.
    // const fruity2 = ???
    

    // #4 This code encounters an error and crashes on the second line.
    // Make one change to the first line so that doesn't happen.
    const sheepCount = 0
    sheepCount = sheepCount + 1


    // #5 Some of the following expressions equal the string "101". Others do not.
    // Comment out the ones that don't (add a // at the start of the line), leaving only the ones that do.
    let a1 = "10" + 1
    let a2 = "1" + 01
    let a3 = 4 + 6 + "1"
    let a4 = "102" - 1
    let a5 = 10 * 10 + 1
    let a6 = "" + 202 / 2
    let a7 = 1 + "0" + 1
    let a8 = 10 * (10 + "1")


    // #6 Put these lines into the correct order so that the variable 'ten' equals 10
    const foo = qux + bar
    const ten = foo + bar;
    bar = bar + 2
    const qux = 2 
    let bar = qux + 1

};
